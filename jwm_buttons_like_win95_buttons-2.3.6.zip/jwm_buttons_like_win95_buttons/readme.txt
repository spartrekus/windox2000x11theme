
1. unpack jwm 2.6  (with libpng-dev installed)
2. mkdir .fbpanel/win95 with the png's of the buttons 
3. add this to icons.c with 16 16 size
4. compile jwm and go to src/ and move jwm to /usr/bin/jwm

 

